package codes.biscuit.skyblockaddons.asm.hooks;

import codes.biscuit.skyblockaddons.SkyblockAddons;
import codes.biscuit.skyblockaddons.tweaker.PreTransformationChecks;
import net.minecraft.client.Minecraft;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.IChatComponent;

public class GuiNewChatHook {

    public static String getUnformattedText(IChatComponent iChatComponent) {
        SkyblockAddons main = SkyblockAddons.getInstance();
        ICommandSender player = Minecraft.getMinecraft().thePlayer;
        if (main != null && PreTransformationChecks.isDeobfuscated() || (player != null && player.getName().equals("Biscut"))) {
            return iChatComponent.getFormattedText(); // makes it easier for debugging
        }
        return iChatComponent.getUnformattedText();
    }
}
