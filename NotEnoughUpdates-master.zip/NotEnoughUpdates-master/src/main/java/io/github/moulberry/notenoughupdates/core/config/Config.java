package io.github.moulberry.notenoughupdates.core.config;

public class Config {

    public void executeRunnable(int runnableId) {
    }

}
