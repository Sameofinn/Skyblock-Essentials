package io.github.moulberry.notenoughupdates.overlays;

public enum TextOverlayStyle {

    BACKGROUND,
    NO_SHADOW,
    MC_SHADOW,
    FULL_SHADOW

}
